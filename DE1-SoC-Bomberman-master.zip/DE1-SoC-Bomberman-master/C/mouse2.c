#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <linux/input.h>

const INPUT_INCLINACAO = 65;
const INPUT_INCLINACAO_MOUSE = 5;


//Directions
#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3

int main() {
    int fd;
    struct input_event ev;

    int mouse_x, mouse_y;

    // Abrindo o dispositivo de entrada do mouse
    fd = open("/dev/input/event0", O_RDONLY);  // Substitua X pelo número correto do seu dispositivo
    if (fd == -1) {
        perror("Erro ao abrir o dispositivo de entrada");
        return -1;
    }

    while (1) {
        // Lendo o evento do dispositivo
        if (read(fd, &ev, sizeof(struct input_event)) < sizeof(struct input_event)) {
            perror("Erro ao ler o evento");
            close(fd);
            return -1;
        }

        // Verificando se o evento é de movimento do mouse (REL_X ou REL_Y)
        if (ev.type == EV_REL) {
            if (ev.code == REL_X) {
                printf("Movimento no eixo X: %d\n", ev.value);
                mouse_x = ev.value;
            } else if (ev.code == REL_Y) {
                printf("Movimento no eixo Y: %d\n", ev.value);
                mouse_y = -ev.value;
            }
        }
        int direcao = readInputsP2(mouse_x,mouse_y);
        printf("Direcao: %d\n", direcao);
    }

    close(fd);
    return 0;
}

int readInputsP2(int mouse_x, int mouse_y)
{
    if (abs(mouse_x) > abs(mouse_y))
    {
        if (mouse_x > INPUT_INCLINACAO_MOUSE) 
            return RIGHT;
        else if (mouse_x < -INPUT_INCLINACAO_MOUSE)
            return LEFT;
    }

    if (mouse_y > INPUT_INCLINACAO_MOUSE) 
        return UP;
    else if (mouse_y < -INPUT_INCLINACAO_MOUSE)
        return DOWN;

    return -1; 
}

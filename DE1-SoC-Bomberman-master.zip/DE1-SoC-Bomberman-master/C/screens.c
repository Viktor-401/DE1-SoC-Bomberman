// colocar as telas de pause, vitoria, gameover, menu e etc aqui
// matrizes de 80x60